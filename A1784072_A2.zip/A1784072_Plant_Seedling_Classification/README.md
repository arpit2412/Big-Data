''''''''''''''''''''''''''''''''''''''''''''''
''''''''''''''''''''''''''''''''''''''''''''''
'''''''''''' ARPIT GARG'''''''''''''''''''''''
''''''''''''''A1784072''''''''''''''''''''''''
'''''''''MASTER OF DATA SCIENCE'''''''''''''''
''''''THE UNIVERSITY OF ADELAIDE''''''''''''''
''''''''''''''''''''''''''''''''''''''''''''''
''''''''''''''''''''''''''''''''''''''''''''''



''''''''''''''''''''''''''''''''''''''''''''''
''''''''''KAGGLE COMPETITION''''''''''''''''''
''''''''''''''''''''''''''''''''''''''''''''''
'''''PLANT SEEDLING CLASSIFICATION:'''''''''''
''''''''''''''''''''''''''''''''''''''''''''''


''''''''''''''''''''''''''''''''''''''''''''''
''''''''''DEPENDENCIES/LIBRARIES''''''''''''''
''''''''''''''''''''''''''''''''''''''''''''''

For installing all the dependencies please run the below command:

pip install -r requirements.txt

All the libraries with version number is mentioned in the requirements.txt


''''''''''''''''''''''''''''''''''''''''''''''
'''''''''''''RUN PROGRAM''''''''''''''''''''''
''''''''''''''''''''''''''''''''''''''''''''''
To run the program please run the below command:

ipython plant_seedling.py


''''''''''''''''''''''''''''''''''''''''''''''
'''''''''''''''NOTES''''''''''''''''''''''''''
''''''''''''''''''''''''''''''''''''''''''''''
1. Please use CUDA if available.
2. Running time (Approx):
	2.1 Using GPU (cuda): 7-8 Hours 
	2.2 Using CPU: 21-22 Hours



