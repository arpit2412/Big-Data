1. Presentation Video
1.1 MKV Format (Original Recording)
1.2 MP4 Format (Extension Conversion)

2. Presentation Slides 
Format: PDF
Created using PREZI.
