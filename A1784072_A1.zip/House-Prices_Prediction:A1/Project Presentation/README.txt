Sildes are made using Prezi. 
Total number of slides are 18 but due to Prezi format it's showing 36. Overall presentation is of less than 5 minutes.
